import telebot
import json
bot=telebot.teleBot()
print("You have woken up my bot \n",bot.get_me(),"\n=======\n")
def user_verif(user):
    with open("databank.json",'+' as file:
        list=json.load(file)
        users=list["users"]
        if user not in users:
            users.append(user)

@bot.message_handler(commands=['start'])
def handle_text(message):
    user=message.chat.id
    bot.send_message("Hello,fellow. Your ID is "+ str(message.chat.id))
